******************
*AndrewR Software*
*Long Timer 1.0.2*
*     README     *
******************

Contents:
1. License
2. Installation instructions
3. Workings of the control
4. Known issues
5. Contact info.
6. Revision

1: License
----------
Long Timer is copyright � Andrew Rendle 1999-2001

Long Timer is provided "as is."  In no event shall I, Andrew Rendle, the author, be liable for any damages resulting from use of this control or inclusion of it in your software.  There is no warranty associated with this software, and it moy not be error free.  You may not reverse engineer, decompile or translate this software.
This software is freeware, and may be included in your software, on the condition that you give me, Andrew Rendle, credit for producing this control.  If you wish to redistribute this control, please contact me (see below) for permission.
Although no charge is made for Long Timer, I would be happy to accept any donations you might wish to send me (optimism is a wonderful thing!), again, see below for contact details.



2: Installation
---------------
If you are using Winzip, click the "install" button or chose install from the Actions menu.  if you are using some other zip software, it may have an install feature.  If so, use that, otherwise extract the contents of this zip file to a tempory directory, and run the install file.



3: Workings of the control
--------------------------
Long Timer's front-end is designed to replicate the standard VB timer control's.  The Enabled and Interval properties work in the same way as the standard control's (in addition to the usual Top, Left, Index, etc. which act as usual.)



4: Known Issues
---------------
There is a possibility that the control may run slow by small periods of time over long intervals.  I have not been able to perform accurate enough testing to check whethe or not this happens, but if it did, it would only be *very* small ammounts of time, and would probably take quite some time to build up to even 1 ms (the smallest unit of time as far as the control is concerned)



5: Contact details
------------------

email: andrew@andrewr.co.uk
ICQ: 53186881
I am intentionally not including postal mail or phone contact info.



6: Revisions
------------
1.0.2 : Bug fix.
1.0.1 : It works.
1.0.0 : It should work.